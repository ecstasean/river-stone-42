# Runner game for her

Tap-to-jump runner. Collect steak tacos, dodge rocks, reach the final message.

## Files that go in the game folder
main.py, player.png, player_run1.png, player_run2.png, music.ogg

(make_sprite.py is only for regenerating the character; it does not go in the
game folder.)

## Steps
1. Install:  pip install pygame pygbag pillow
2. Make a folder called `runner` and put the files above in it.
3. Edit the top of `main.py`: HER_NAME, FINAL_LINES, TACOS_TO_WIN, LIVES.
4. Get a royalty-free neo-soul track, convert to .ogg, name it music.ogg:
       ffmpeg -i song.mp3 -c:a libvorbis -q:a 4 music.ogg
   (Keep it under about 3 MB. Trim to 2-3 minutes; it loops.)
5. Test on your computer:  cd runner && python main.py
   (click or press space to jump)
6. Build for the web:  pygbag --build runner
   Output: runner/build/web/
7. Publish with GitHub Pages:
       cd runner/build/web
       git init && git add . && git commit -m "game"
       git branch -M main
       git remote add origin https://github.com/<you>/<repo>.git
       git push -u origin main
   Then repo Settings > Pages > Deploy from branch > main / (root).
   Link: https://<you>.github.io/<repo>/   (takes 1-2 minutes)
8. Open the link on your phone (mobile data, not Wi-Fi) and play to the end.
9. Send her the link.

## Notes
- Audio only starts after the first tap (browser rule), which is built in.
- After the final message there is a ~3 second lock so she can't tap past it.
- Don't put photos of her in the repo; Pages sites are public.
- To change the character's colors, edit make_sprite.py and run it again.
