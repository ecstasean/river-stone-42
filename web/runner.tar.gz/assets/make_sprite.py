"""Generates the pixel-art character for the runner game.

Run:  python make_sprite.py
Makes: player.png, player_run1.png, player_run2.png (72x96, transparent)
       preview.png (big preview so you can check the look)

Tweak the colors in PAL / OUTLINE below, or edit the BASE pixel map.
Each letter in BASE is one pixel (24 wide x 23 tall); legs are added below.
"""
from PIL import Image

# ---------------- colors: tweak these ----------------
PAL = {
    "K": (25, 20, 22),     # black locs
    "H": (72, 64, 78),     # loc highlights
    "B": (20, 15, 15),     # black eyebrows
    "S": (150, 98, 64),    # brown skin
    "D": (122, 76, 48),    # skin shadow
    "E": (55, 32, 22),     # doe brown eyes
    "W": (245, 240, 235),  # eye sparkle
    "R": (150, 60, 70),    # lips
    "G": (235, 185, 50),   # gold (piercings, ankh)
    "T": (250, 245, 235),  # crop top
    "P": (214, 92, 140),   # skirt
    "p": (178, 60, 110),   # skirt pleat shade
    "U": (90, 60, 140),    # butterfly tattoo ink
    "F": (245, 245, 245),  # ballet shoes
    "f": (165, 165, 178),  # shoe shade
}
OUTLINE = (35, 22, 18)
# -----------------------------------------------------

W, H = 24, 32

BASE = [
    "........................",  # 0
    ".......KKHKKKHKKK.......",  # 1  curly locs, top
    ".....KHKKKKHKKKKHKK.....",  # 2
    "....KKKHKKKKKKKKHKKK....",  # 3
    "....KKKKKKKKKKKKKKKK....",  # 4
    "....KKHKKKKKKKKKKHKK....",  # 5  fringe
    "....KKKSSSSSSSSSSKKK....",  # 6  forehead
    "....KKKSBBBSSBBBSKKK....",  # 7  black brows
    "....KKKSKWESSWEKSKKK....",  # 8  eyes + lashes + sparkle
    "....KKKSSEESSEESSKKK....",  # 9  doe eyes
    "....KKKSSSSDDGSSSKKK....",  # 10 nose + nose piercing (her left)
    "....KKKSSSSGGSSSSKKK....",  # 11 septum ring
    "....KKKSSSRRRRSSSKKK....",  # 12 lips
    "....KKKKSSSSSSSSKKKK....",  # 13 chin
    "....KKK...DDDD...KKK....",  # 14 neck
    "....KKKTTSGSSGSTTKKK....",  # 15 chain
    "....KHKTTTTGGTTTTKHK....",  # 16 ankh loop
    "....TTTTTTGGGGTTTTTT....",  # 17 ankh arms + sleeves
    "....SS.TTTTGGTTTT.SS....",  # 18 ankh stem
    "....SS..SSSSSSSS..UU....",  # 19 midriff, butterfly tattoo
    "....SS..PPPPPPPP..US....",  # 20 skirt
    "....SS.PPPPPPPPPP.SS....",  # 21
    "....SSpPpPpPpPpPpPSS....",  # 22 hem
]
assert all(len(r) == W for r in BASE), [len(r) for r in BASE]

# bumpy side edges so the locs read as curly instead of straight
for _y in (6, 8, 10, 12, 14, 16):
    _row = list(BASE[_y])
    _row[3] = "K"
    _row[20] = "K"
    BASE[_y] = "".join(_row)


def blank():
    g = [["."] * W for _ in range(H)]
    for y, row in enumerate(BASE):
        for x, c in enumerate(row):
            g[y][x] = c
    return g


def leg(g, cols, lift, shift=0):
    a, b = cols[0] + shift, cols[1] + shift
    for y in range(23, 28 - lift):
        g[y][a] = g[y][b] = "S"
    sy = 28 - lift
    for x in range(a - 1, b + 2):
        g[sy][x] = "F"
        g[sy + 1][x] = "f"


def frame(left_lift=0, right_lift=0):
    g = blank()
    leg(g, (9, 10), left_lift, shift=-1 if left_lift else 0)
    leg(g, (13, 14), right_lift, shift=1 if right_lift else 0)
    return g


def render(g):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    px = img.load()
    for y in range(H):
        for x in range(W):
            c = g[y][x]
            if c != ".":
                px[x, y] = PAL[c] + (255,)
    # automatic dark outline around the whole character
    filled = {(x, y) for y in range(H) for x in range(W) if g[y][x] != "."}
    for (x, y) in filled:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < W and 0 <= ny < H and (nx, ny) not in filled:
                px[nx, ny] = OUTLINE + (255,)
    return img


frames = {
    "player.png": frame(0, 0),
    "player_run1.png": frame(2, 0),
    "player_run2.png": frame(0, 2),
}
imgs = {}
for name, g in frames.items():
    small = render(g)
    big = small.resize((72, 96), Image.NEAREST)
    big.save(name)
    imgs[name] = small

# preview sheet
scale = 10
sheet = Image.new("RGBA", (W * scale * 3 + 40, H * scale + 20), (190, 225, 250, 255))
for i, name in enumerate(frames):
    p = imgs[name].resize((W * scale, H * scale), Image.NEAREST)
    sheet.alpha_composite(p, (10 + i * (W * scale + 10), 10))
sheet.save("preview.png")
print("done")
