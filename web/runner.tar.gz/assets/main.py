import asyncio
import math
import os
import random

import pygame

# =====================  CUSTOMIZE ME  =====================
HER_NAME = "Little Mel"
TACOS_TO_WIN = 15             # steak tacos she must collect to reach the message
LIVES = 3                     # forgiving on purpose, so she doesn't rage-quit
PLAYER_SPRITE = "player.png"  # run frames: player_run1.png / player_run2.png
MUSIC_FILE = "music.ogg"      # royalty-free neo-soul track, .ogg format
MUSIC_VOLUME = 0.5

# Final message. Keep each line under ~34 characters, and use at most
# 4 lines after the big title line and the blank line.
FINAL_LINES = [
    f"You did it, !",   # shown big
    "",
]
# ==========================================================

W, H = 800, 400
GROUND = 330
GRAVITY = 0.9
JUMP_V = -16.5
PLAYER_X = 110
PLAYER_W, PLAYER_H = 72, 96

pygame.init()
screen = pygame.display.set_mode((W, H), pygame.SCALED)
pygame.display.set_caption("Run!")
clock = pygame.time.Clock()
font_big = pygame.font.Font(None, 56)
font = pygame.font.Font(None, 36)
font_small = pygame.font.Font(None, 26)


def load_placeholder():
    s = pygame.Surface((PLAYER_W, PLAYER_H), pygame.SRCALPHA)
    pygame.draw.rect(s, (60, 35, 25), (6, 0, 36, 34), border_radius=14)
    pygame.draw.circle(s, (150, 98, 64), (24, 20), 13)
    pygame.draw.rect(s, (230, 90, 140), (12, 34, 24, 20), border_radius=6)
    pygame.draw.rect(s, (50, 50, 70), (14, 54, 8, 10))
    pygame.draw.rect(s, (50, 50, 70), (26, 54, 8, 10))
    return s


def load_frames():
    """Returns [jump/stand, run1, run2]."""
    base = os.path.splitext(PLAYER_SPRITE)[0]
    names = [PLAYER_SPRITE, f"{base}_run1.png", f"{base}_run2.png"]
    if os.path.exists(PLAYER_SPRITE):
        frames = []
        for n in names:
            path = n if os.path.exists(n) else PLAYER_SPRITE
            img = pygame.image.load(path).convert_alpha()
            frames.append(pygame.transform.scale(img, (PLAYER_W, PLAYER_H)))
        return frames
    return [load_placeholder()] * 3


player_frames = load_frames()


def start_music():
    # Browsers only allow audio after a tap, so this is called on the first tap.
    try:
        if os.path.exists(MUSIC_FILE):
            pygame.mixer.music.load(MUSIC_FILE)
            pygame.mixer.music.set_volume(MUSIC_VOLUME)
            pygame.mixer.music.play(-1)
    except Exception as e:  # never let audio problems crash the game
        print("music failed:", e)


def draw_heart(surf, cx, cy, size, color=(235, 60, 100)):
    r = size // 4
    pygame.draw.circle(surf, color, (cx - r, cy - r // 2), r)
    pygame.draw.circle(surf, color, (cx + r, cy - r // 2), r)
    pygame.draw.polygon(
        surf, color,
        [(cx - 2 * r, cy - r // 4), (cx + 2 * r, cy - r // 4), (cx, cy + int(1.6 * r))],
    )


def draw_taco(surf, cx, cy, size=34):
    """Steak taco: shell on the bottom, steak, lettuce and tomato on top."""
    r = size // 2
    pygame.draw.circle(surf, (90, 170, 70), (cx - r // 2, cy - r // 3), r // 3 + 1)   # lettuce
    pygame.draw.circle(surf, (90, 170, 70), (cx + r // 2, cy - r // 3), r // 3 + 1)
    pygame.draw.circle(surf, (125, 72, 46), (cx - r // 4, cy - r // 2), r // 3 + 1)   # steak
    pygame.draw.circle(surf, (105, 58, 38), (cx + r // 4, cy - r // 2 + 1), r // 3 + 1)
    pygame.draw.circle(surf, (220, 60, 50), (cx, cy - r // 4), r // 6 + 1)            # tomato
    pts = [(cx + int(r * math.cos(math.radians(a))), cy + int(r * math.sin(math.radians(a))))
           for a in range(0, 181, 10)]
    pygame.draw.polygon(surf, (238, 195, 95), pts)                                    # shell
    pygame.draw.polygon(surf, (196, 146, 52), pts, 2)


def draw_text_center(text, f, y, color=(40, 40, 60)):
    img = f.render(text, True, color)
    screen.blit(img, (W // 2 - img.get_width() // 2, y))


class Game:
    def __init__(self):
        self.reset()

    def reset(self):
        self.state = "start"
        self.y = float(GROUND - PLAYER_H)
        self.vy = 0.0
        self.speed = 6.0
        self.objects = []
        self.next_spawn = 500
        self.tacos = 0
        self.lives = LIVES
        self.invuln = 0
        self.lock = 0          # blocks taps briefly on end screens
        self.scroll = 0.0
        self.clouds = [[random.randint(0, W), random.randint(30, 140), random.randint(40, 80)]
                       for _ in range(5)]

    @property
    def on_ground(self):
        return self.y >= GROUND - PLAYER_H

    def jump(self):
        if self.on_ground:
            self.vy = JUMP_V

    def spawn(self):
        x = W + 20
        if random.random() < 0.45:
            air = random.random() < 0.5
            y = GROUND - (110 if air else 34)
            self.objects.append({"kind": "taco", "x": x, "y": y, "w": 34, "h": 32})
        else:
            h = random.randint(28, 52)
            w = random.randint(28, 44)
            self.objects.append({"kind": "rock", "x": x, "y": GROUND - h, "w": w, "h": h})
        self.next_spawn = random.randint(300, 520) + int(self.speed * 12)

    def player_rect(self):
        return pygame.Rect(PLAYER_X + 8, int(self.y) + 6, PLAYER_W - 16, PLAYER_H - 8)

    def update(self):
        if self.lock > 0:
            self.lock -= 1
        if self.state != "play":
            return
        self.speed = min(11.0, self.speed + 0.002)
        self.scroll += self.speed

        self.vy += GRAVITY
        self.y += self.vy
        if self.y >= GROUND - PLAYER_H:
            self.y = GROUND - PLAYER_H
            self.vy = 0.0

        self.next_spawn -= self.speed
        if self.next_spawn <= 0:
            self.spawn()

        for c in self.clouds:
            c[0] -= self.speed * 0.2
            if c[0] < -100:
                c[0] = W + random.randint(0, 200)
                c[1] = random.randint(30, 140)

        if self.invuln > 0:
            self.invuln -= 1

        pr = self.player_rect()
        for o in self.objects[:]:
            o["x"] -= self.speed
            r = pygame.Rect(int(o["x"]), int(o["y"]), o["w"], o["h"])
            if o["kind"] == "taco" and pr.colliderect(r.inflate(10, 10)):
                self.objects.remove(o)
                self.tacos += 1
                if self.tacos >= TACOS_TO_WIN:
                    self.state = "win"
                    self.lock = 180   # ~3s so she can't tap past the message
            elif o["kind"] == "rock" and self.invuln == 0 and pr.colliderect(r.inflate(-6, -4)):
                self.objects.remove(o)
                self.lives -= 1
                self.invuln = 70
                if self.lives <= 0:
                    self.state = "over"
                    self.lock = 40
            elif o["x"] < -60:
                self.objects.remove(o)

    def draw(self):
        screen.fill((190, 225, 250))
        for x, y, w in self.clouds:
            pygame.draw.ellipse(screen, (255, 255, 255), (int(x), y, w * 2, w // 2))
        pygame.draw.rect(screen, (110, 190, 110), (0, GROUND, W, H - GROUND))
        pygame.draw.line(screen, (70, 140, 70), (0, GROUND), (W, GROUND), 4)
        for i in range(0, W + 80, 80):
            x = i - int(self.scroll) % 80
            pygame.draw.line(screen, (90, 165, 90), (x, GROUND + 20), (x + 30, GROUND + 20), 3)

        for o in self.objects:
            if o["kind"] == "taco":
                draw_taco(screen, int(o["x"]) + 17, int(o["y"]) + 15, 34)
            else:
                pygame.draw.rect(screen, (120, 120, 130),
                                 (int(o["x"]), int(o["y"]), o["w"], o["h"]), border_radius=8)

        if not (self.invuln > 0 and (self.invuln // 5) % 2 == 0):
            if self.on_ground:
                img = player_frames[1 + (int(self.scroll) // 60) % 2]  # run cycle
            else:
                img = player_frames[0]  # in the air
            screen.blit(img, (PLAYER_X, int(self.y)))

        # HUD
        draw_taco(screen, 34, 26, 32)
        screen.blit(font.render(f"{self.tacos}/{TACOS_TO_WIN}", True, (40, 40, 60)), (58, 14))
        for i in range(self.lives):
            draw_heart(screen, W - 34 - i * 34, 26, 28)

        if self.state == "start":
            self.panel()
            draw_text_center(f"Run, {HER_NAME}!", font_big, 125)
            draw_text_center(f"Collect {TACOS_TO_WIN} steak tacos", font, 190)
            draw_text_center("Tap to jump. Dodge the rocks!", font_small, 232)
            draw_text_center("Tap to start", font_small, 262, (120, 120, 140))
        elif self.state == "over":
            self.panel()
            draw_text_center("Oops! So close.", font_big, 140)
            if self.lock == 0:
                draw_text_center("Tap to try again", font, 210)
        elif self.state == "win":
            self.panel(tall=True)
            y = 90
            for line in FINAL_LINES:
                draw_text_center(line, font_big if line == FINAL_LINES[0] else font, y)
                y += 62 if line == FINAL_LINES[0] else 40
            if self.lock == 0:
                draw_text_center("Tap to play again", font_small, 345, (120, 120, 140))

    def panel(self, tall=False):
        top, height = (60, 290) if tall else (100, 190)
        s = pygame.Surface((W - 160, height), pygame.SRCALPHA)
        s.fill((255, 255, 255, 220))
        screen.blit(s, (80, top))


async def main():
    g = Game()
    while True:
        tapped = False
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            if e.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                tapped = True
            if e.type == pygame.KEYDOWN and e.key in (pygame.K_SPACE, pygame.K_UP):
                tapped = True

        if tapped:
            if g.state == "play":
                g.jump()
            elif g.state == "start":
                g.state = "play"
                start_music()
            elif g.lock == 0:      # over / win, only after the lock ends
                g.reset()
                g.state = "play"

        g.update()
        g.draw()
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)  # required by pygbag


asyncio.run(main())
